#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "lists.h"

// insert proper tests here
int main (int argc, const char * argv[]) {

   link list;
   node first;
   node second;
   node third;
   node fourth;
   node fifth;
   node sixth;

   setbuf(stdout, NULL);

   printf("Testing... sumListItems\n");

   printf("Test 1: ");
   first.item = 5;
   list = &first;
   first.next = NULL;
   printList(list);
   assert(sumListItems (list) == 5);
   printf("Test 1 passed!\n");

   printf("Test 2: ");
   first.item = 1;
   list = &first;
   second.item = 2;
   first.next = &second;
   third.item = 3;
   second.next = &third;
   fourth.item = 4;
   third.next = &fourth;
   fifth.item = 5;
   fourth.next = &fifth;
   sixth.item = 6;
   fifth.next = &sixth;
   sixth.next = NULL;
   printList(list);
   assert(sumListItems (list) == 21);
   printf("Test 2 passed!\n");

   printf("Test 3: ");
   list = NULL;
   printList(list);
   assert(sumListItems (list) == 0);
   printf("Test 3 passed!\n");

   printf("All sumListItems tests passed. You are Awesome!\n\n");

   printf("Testing... fromTo\n");

   printf("Test 1: fromTo(1, 5)\n");
   list = fromTo (1, 5);
   assert(list->item == 1);
   assert(list->next != NULL);
   list = list->next;
   assert(list->item == 2);
   assert(list->next != NULL);
   list = list->next;
   assert(list->item == 3);
   assert(list->next != NULL);
   list = list->next;
   assert(list->item == 4);
   assert(list->next != NULL);
   list = list->next;
   assert(list->item == 5);
   assert(list->next == NULL);
   printf("Test 1 passed!\n");

   printf("Test 2: fromTo(1, 1)\n");
   list = fromTo (1, 1);
   assert(list->item == 1);
   assert(list->next == NULL);
   printf("Test 2 passed!\n");

   printf("Test 3: fromTo(2, 1)\n");
   list = fromTo (2, 1);
   assert(list == NULL);
   printf("Test 3 passed!\n");

   printf("All fromTo tests passed. You are Awesome!\n\n");

   printf("Testing... doublify\n");
   dlink dlist, dprev;

   printf("Test 1: ");
   first.item = 5;
   list = &first;
   first.next = NULL;
   printList(list);
   dlist = doublify(list);
   assert(dlist->item == 5);
   assert(dlist->prev == NULL);
   assert(dlist->next == NULL);
   printf("Test 1 passed!\n");

   printf("Test 2: ");
   first.item = 1;
   list = &first;
   second.item = 2;
   first.next = &second;
   third.item = 3;
   second.next = &third;
   third.next = NULL;
   printList(list);
   dlist = doublify(list);
   assert(dlist->item == 1);
   assert(dlist->prev == NULL);
   assert(dlist->next != NULL);
   dprev = dlist;
   dlist = dlist->next;
   assert(dlist->item == 2);
   assert(dlist->prev == dprev);
   assert(dlist->next != NULL);
   dprev = dlist;
   dlist = dlist->next;
   assert(dlist->item == 3);
   assert(dlist->prev == dprev);
   assert(dlist->next == NULL);
   printf("Test 2 passed!\n");

   printf("Test 3: ");
   list = NULL;
   printList(list);
   dlist = doublify(list);
   assert(dlist == NULL);
   printf("Test 3 passed!\n");

   printf("All doublify tests passed. You are Awesome!\n\n");
   return 0;
}
