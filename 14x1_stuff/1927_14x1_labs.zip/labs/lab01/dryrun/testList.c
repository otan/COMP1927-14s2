#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "lists.h"

static link newNode (Item item) {
  link ls;
  ls = malloc (sizeof (*ls));
  ls->item = item;
  return ls;     
}

link insertFront(link ls, Item i){
    link n = newNode(i);
    n->next = ls;
    return n;
}

// insert proper tests here
int main (int argc, const char * argv[]) {
    setbuf(stdout, NULL);
    if(argc <=1){
       printf("Incorrect usage\n");
    }
    int test = atoi(argv[1]);
    if(test == 0){
       printf("Testing freeList\n");
       link list = NULL;
       freeList(list);
       int i;
       for(i= 3; i <= 33; i+=10){
            list = insertFront(list,i);
       }
       freeList(list);
    } else if(test == 1){
        printf("Testing... sumListItems\n");

        printf("Test 1: Empty List\n");
        link list = NULL;
        printList(list);
        assert(sumListItems(list) == 0);
        printf("Test 1 passed!\n\n");


   	printf("Test 2: List size 1\n");
        list = insertFront(list,5);
        printList(list);
        assert(sumListItems(list) == 5);
        printf("Test 2 passed\n\n");
   
        printf("Test 3: List size 2\n");
        list = insertFront(list,2);
        printList(list);
        assert(sumListItems (list) == 7);
        printf("Test 2 passed!\n\n");

        printf("Test 4: longer list\n");
        //add 3, 13, 23, 33 = 79
        int i;
        for(i= 3; i <= 33; i+=10){
            list = insertFront(list,i);
        }
        printList(list);
        assert(sumListItems(list) == 79);
        printf("Test 4 passed!\n\n");
        printf("All sumListItems tests passed. You are Awesome!\n\n");
    } else if(test == 2){
        printf("Testing... fromTo\n");

        printf("Test 1: fromTo(7, 5) - Empty List\n");
        link list = fromTo (7, 5);
        printList(list);
        assert(list == NULL);
        printf("Test 1 passed!\n");

        printf("Test 2: fromTo(1, 1)\n");
        list = fromTo (5, 5);
        printList(list);
        assert(list != NULL);
        assert(list->item == 5);
        assert(list->next == NULL);
        printf("Test 2 passed!\n");

        printf("Test 3: fromTo(20, 30)\n");
        list = fromTo (20, 30);
        printList(list);
        assert(list != NULL);
        int i;
        for(i = 20; i<30; i++){
            assert(list->item == i);
            assert(list->next != NULL);
            list = list->next;             
        }
        assert(list->item == 30);
        assert(list->next == NULL);
        printf("Test 3 passed!\n");

        printf("All fromTo tests passed. You are Awesome!\n\n");
    } else if (test == 3){     
        printf("Testing... doublify\n");
        
        dlink dlist;

        printf("Test 1: Empty List\n");
        link list = NULL;
        dlist = doublify(list);
        assert(dlist == NULL); 
        printf("Test 1 passed!\n");

        printf("Test 2: List size 1\n");
        list = insertFront(list,10);   
        printList(list);
        dlist = doublify(list);
        assert(dlist != NULL);
        assert(dlist->item == 10);
        assert(dlist->prev == NULL);
        assert(dlist->next == NULL);
        printf("Test 2 passed!\n");

        printf("Test 3: List size 2\n");
        list = insertFront(list,0);
        printList(list);
        dlist = doublify(list);
        assert(dlist != NULL);
        assert(dlist->item == 0);  
        assert(dlist->prev == NULL);
        assert(dlist->next != NULL);
        assert(dlist->next->item == 10);
        assert(dlist->next->next == NULL);
        assert(dlist->next->prev == dlist);
        assert(dlist->next->prev->item == 0); 
        printf("Test 3 passed!\n");

        printf("Test 4: Bigger list\n");
        int i;
        for(i=1; i< 5; i++){
            list = insertFront(list, i);
        }
        printList(list);
        dlist = doublify(list);
        dlink prev = NULL;
        dlink tmp = dlist;
        for(i=4; i >=0; i--){
            assert(tmp != NULL);
            assert(tmp->item == i);   
            assert(tmp->prev == prev);
            assert(tmp->next != NULL);
            prev = tmp;
            tmp = tmp->next;
        }
        assert(tmp->item == 10);
        assert(tmp->next == NULL);
        assert(tmp->prev == prev);
        printf("Test 4 passed!\n");

        printf("All doublify tests passed. You are Awesome!\n\n");
    }   
    return 0;
}
