#!/bin/sh

# signal values
# 128+6
SIGABRT=134
# 128+9
SIGKILL=137
# 128+11
SIGSEGV=139

COMPILE_OPTIONS="-Wall -Werror -O"

DRYRUNDIR=$1
shift

PROGRAM=$1
shift

echo "Compiling your program ... $PROGRAM"
echo

echo "Test files from $DRYRUNDIR"
echo

cp $DRYRUNDIR/$PROGRAM.h .

compiled=0
for tester in testList
do
    cp $DRYRUNDIR/$tester.c .
    compile="gcc $COMPILE_OPTIONS -o tester_$tester $PROGRAM.c $tester.c"
    echo $compile
    eval $compile
    test -x tester_$tester && compiled=`expr $compiled + 1`
    echo
done
echo

test $compiled -eq 0 && { echo "Compilation errors?"; exit 1; }

echo "Testing your program ..."
echo


failed=0
for tester in testList
do
    test -x tester_$tester || continue
    case $tester in
	testList)
	    tests="0 1 2 3"
	    ;;
	testIntList2)
	    tests="randomData"
	    ;;
    esac
    for test in $tests
    do
	echo "$tester $test"
	echo "------------------------------"
	case $test in
	    0)
		execute="timelim 3 valgrind --error-exitcode=1 --leak-check=full ./tester_$tester $test > testing.out 2> error.out"
		;;
            *) 
		execute="timelim 3 ./tester_$tester $test > testing.out 2> error.out"

	esac
	echo $execute
	eval $execute
	execute_status=$?
	cat testing.out
	cat error.out
        if [ $execute_status -eq $SIGKILL ]
	then
            echo "** CPU time limit exceeded"
            failed=`expr $failed + 1`
        elif [ $execute_status -eq $SIGSEGV ]
	then
            echo "** Segmentation fault"
            failed=`expr $failed + 1`
	elif [ $execute_status -ne 0 ]
	then
            echo "** Failed."
            failed=`expr $failed + 1`
	else
            echo "** Passed."
	fi
	echo
    done
done

if [ $failed -eq 0 ]
then
    echo "** Passed the given tests. You are Awesome!"
    exit 0
else
    echo "** Failed at least one of the given test."
    exit 1
fi
