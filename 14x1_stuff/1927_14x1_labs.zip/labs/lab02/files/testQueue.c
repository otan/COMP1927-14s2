#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "Item.h"
#include "Queue.h"

void queueWhiteBoxTests(void);
int main (int argc, char *argv[]){
    //Run white box tests
    queueWhiteBoxTests();

    //Run black box tests
    printf("Black Box tests:\n");


    return 0;
}       
