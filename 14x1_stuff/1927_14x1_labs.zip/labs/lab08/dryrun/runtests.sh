#!/bin/sh

# signal values
# 128+6
SIGABRT=134
# 128+9
SIGKILL=137
# 128+11
SIGSEGV=139

COMPILE_OPTIONS="-std=c99 -Wall -Werror -O -lm"

DRYRUNDIR=$1
shift

echo
echo "Test files from $DRYRUNDIR"

ulimit -c 0
failed=0
for program
do
    echo
    echo "============================"
    echo "$program"
    echo "============================"
    if [ ! -f $program ]
    then
	echo "** File $program missing"
	failed=`expr $failed + 1`
	continue
    fi

    case "$program" in
	Tree.c)
            testfiles="Makefile Item.h Tree.h words.c words3.c dictTest result1 result2 result3 result4"
	    tests[1]="./words dictTest 0"
	    tests[2]="./words dictTest 1"
	    tests[3]="./words dictTest 2"
	    tests[4]="./words3 dictTest 5"
	    diff="diff -y -W 120"
	    ;;
	*)
	    echo "** $program ???"
	    failed=`expr $failed + 1`
	    continue
	    ;;
    esac

    echo
    echo "Copying files ... $testfiles"
    for f in $testfiles
    do
	cp $DRYRUNDIR/$f .
    done

    echo
    echo "Compiling your program ... make"
    if make
    then
	echo "** Compiled OK."
    else
	echo "** Compiling errors?"
	failed=`expr $failed + 1`
	continue
    fi
    
    echo
    echo "Testing your program ..."
    for test in `seq -w ${#tests[*]}`
    do
	echo "----------------------------"
	echo "Test $test"
	echo "----------------------------"
	
        execute="timelim 3 ${tests[$test]} > output 2>&1"
        echo $execute
        eval $execute
        execute_status=$?
	echo "** Your Output:"
        cat output | stufilter +200 -20
        if [ $execute_status -eq $SIGKILL ]
        then
            echo "** CPU time limit exceeded"
            failed=`expr $failed + 1`
        elif [ $execute_status -eq $SIGSEGV ]
        then
            echo "** Segmentation fault"
            failed=`expr $failed + 1`
        elif [ $execute_status -ne 0 ]
        then
            # exit: failure
            echo "** Failed."
            failed=`expr $failed + 1`
        else
            # exit: success
	    compare="$diff output result$test > 
diff.out"
	    echo $compare
	    eval $compare
	    compare_status=$?
	    if [ $compare_status -eq 0 ]
	    then
                echo "** Passed."
	    else
		echo "** Differences between your output and sample output"
		cat diff.out
                echo "** Failed."
                failed=`expr $failed + 1`
	    fi
        fi
    done
done


echo
if [ $failed -eq 0 ]
then
    echo "** Passed the given tests. You are Awesome!"
    exit 0
else
    echo "** Failed at least one of the given test."
    exit 1
fi
