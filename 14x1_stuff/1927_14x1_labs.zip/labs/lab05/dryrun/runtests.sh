#!/bin/sh

# signal values
# 128+6
SIGABRT=134
# 128+9
SIGKILL=137
# 128+11
SIGSEGV=139

COMPILE_OPTIONS="-std=c99 -Wall -Werror -O"

DRYRUNDIR=$1
shift

PROGRAM=$1
shift

echo "Test files from $DRYRUNDIR"
echo

n=1
compiled=0
for tester in $PROGRAM
do
    echo "Compiling your program ... $tester"
    echo
   
    compile="gcc $COMPILE_OPTIONS -o tester_$tester $tester.c"
    echo $compile
    eval $compile
    test -x tester_$tester && compiled=`expr $compiled + 1`
    echo
done
echo

test $compiled -eq 0 && { echo "Compilation errors?"; exit 1; }

echo "Testing your program ..."
echo


failed=0

for tester in $PROGRAM
do
    test -x tester_$tester || continue
    case $tester in
	quicksort)
	    tests="test1 test2 test3 test4 test5 test6 test7 test8 test9 test10 test11 test12"
	    results="result1 result2 result3 result5 result6 result7 result8 result9 result10 result11 result12"
	    ;;
    esac
    
    cp $DRYRUNDIR/result* .
    for test in $tests
    do
	cp $DRYRUNDIR/$test .
	echo "$tester $test"
	echo "------------------------------"
	case $test in
	    test1|test2|test3)
		execute="timelim 3 ./tester_$tester -pn < $test > testing.out 2> error.out"
	        ;;
            test4|test5|test6)
		execute="timelim 3 ./tester_$tester -pm < $test > testing.out 2> error.out"
        	;;
	    *)
                execute="timelim 3 ./tester_$tester -pr < $test > testing.out 2> error.out"
                ;;
	esac
	echo $execute
	eval $execute
	execute_status=$?
	#cat testing.out
	cat error.out
        if [ $execute_status -eq $SIGKILL ]
	then
            echo "** CPU time limit exceeded"
            failed=`expr $failed + 1`
        elif [ $execute_status -eq $SIGSEGV ]
	then
            echo "** Segmentation fault"
            failed=`expr $failed + 1`
	elif [ $execute_status -ne 0 ]
	then
            echo "** Failed."
            failed=`expr $failed + 1`
	else
            if ! diff -wB testing.out result$n >out.diff
	    then
                if [ $n -le 9 ]
                then
                    echo "** Test Failed - output diff"
                    cat out.diff
		else
		    echo "** Test Failed - output diff suppressed due to the large test file"
                fi
                failed=`expr $failed + 1`
            else
                echo "** Passed."   
            fi
        fi   
	echo
    n=`expr $n + 1`
    done
done

if [ $failed -eq 0 ]
then
    echo "** Passed the given tests. You are Awesome!"
    echo "** Your tutor will still need to assess your code"
    exit 0
else
    echo "** Failed at least one of the given test."
    exit 1
fi
