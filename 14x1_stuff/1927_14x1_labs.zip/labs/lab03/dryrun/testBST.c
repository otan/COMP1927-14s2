#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "BST.h"

int main () {
    treelink tree = NULL;

    printf("Testing... countLeaves\n");

    printf("Test 1: ");

    int leaves = countLeaves(tree);
    assert(leaves == 0);
    printf("passed\n");

    printf("Test 2: ");
    tree = insertTreeNode (tree, 4);
    tree = insertTreeNode (tree, 2);
    tree = insertTreeNode (tree, 1);
    leaves = countLeaves(tree);
    assert(leaves == 1);
    printf("passed\n");

    printf("Test 3: ");
    tree = insertTreeNode (tree, 3);
    tree = insertTreeNode (tree, 6);
    tree = insertTreeNode (tree, 5);
    leaves = countLeaves(tree);
    assert(leaves == 3);
    printf("passed\n");

    printf("Test 4: ");
    tree = insertTreeNode (tree, 7);
    leaves = countLeaves(tree);
    assert(leaves == 4);
    printf("passed\n");

    printf("\nTesting... searchInsert\n");
    printf("Test 5: ");
    tree = searchInsert(tree,4);
    assert(getItem(search(tree,4)) == 4);
    assert(size(tree) == 7);
    printf("passed\n");

    printf("Test 6: ");
    tree = searchInsert(tree,3);
    assert(getItem(search(tree,3)) == 3);
    assert(size(tree) == 7);
    printf("passed\n");

    printf("Test 7: ");
    tree = searchInsert(tree,98);
    assert(getItem(search(tree,98)) == 98);
    assert(size(tree) == 8);
    printf("passed\n");

    printf("\nTesting... countIf\n");
    printf("Test 8 isEven: ");
    assert(countIf(tree,isEven) == 4); 
    printf("passed\n");

    printf("Test 9 isOdd: ");
    assert(countIf(tree,isOdd) == 4);
    printf("passed\n");

   
    printf("Test 10 isNegative: ");
    assert(countIf(tree,isNegative) == 0);
    printf("passed\n");
    
    printf("\n");
    return (0);
}

