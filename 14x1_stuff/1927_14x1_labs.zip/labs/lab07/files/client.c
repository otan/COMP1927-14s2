#include <stdio.h>
#include <stdlib.h>
#include "Item.h"
#include "ST.h"

#define MAXSIZE 100

void whiteBoxTests(void);

int main (int argc, char *argv[]) { 

  Item currIt;
  int N = 0;

  STinit (MAXSIZE);
  
  while (ITEMscan (&currIt)) {
    STinsert (currIt);
    N++;
  }
  STsort (&ITEMshow);
  whiteBoxTests();
  return EXIT_SUCCESS;
}
