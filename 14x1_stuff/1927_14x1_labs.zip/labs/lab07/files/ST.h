void STinit (int);    /* new symbol table */
 int STcount ();      /* number of items in table */
void STinsert (Item); /* insert an item */
Item STsearch (Key);  /* find item with given key */
void STdelete (Item); /* delete given item */
Item STselect (int);  /* find nth item */
                      /* traverse items in key order */
void STsort (void (*visit)(Item));

