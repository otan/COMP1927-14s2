#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "lists.h"

// insert proper tests here
int main (int argc, const char * argv[]) {
   int vals[] = {2,1,9,8,3,4,6,5,7,0};
   link list;
   int i;

   setbuf(stdout, NULL);

   list = NULL;
  
   for(i=0; i <10; i++){
       list = insertEnd(list,newNode(i));
   }
   printf("Testing 1 insertion sort on ordered list\n");
   list = insertionSort(list);

   link curr = list;
   for(i=0; i<10; i++){
       assert(curr->item == i);
       curr = curr->next;
   }
   assert(curr == NULL);
   freeList(list);
   printf("Test 1 passed!\n");

   list = NULL;
  
   for(i=0; i < 10 ; i++){
       list = insertFront(list,newNode(i));
       
   }
  
   printf("Test 2 insertion sort on reverse ordered list\n");
   list = insertionSort(list);
   curr = list;
   for(i=0; i<10; i++){
       assert(curr->item == i);
       curr = curr->next;
   }
   assert(curr == NULL);
   freeList(list);
   printf("Test 2 passed!\n");
  
   list = NULL;
   for(i=0; i<10; i++){
     list = insertEnd(list,newNode(vals[i]));
   } 
   printf("Test 3: insertion sort on mixed list\n");
 

   list = insertionSort(list);
   curr = list;
   for(i=0; i<10; i++){
       assert(curr->item == i);
       curr = curr->next;
   }
   assert(curr == NULL);
   freeList(list);

   printf("All insertion sort tests passed. You are Awesome!\n\n");

  
   return 0;
}
