#include "isMinHeap.h"
//To compile, run and test
//gcc -Wall -Werror -O -o testIsMinHeap testIsMinHeap.c isMinHeap.c


//return 1 if the array heap with a sepcified number of items is in heap order 
//You must assume that the heap items are in indexes 1..heapSize and that index 0 
//is empty and not used to store items.
int isMinHeap(int heap[], int heapSize){
    //COMPLETE FOR TASK 3
    return 0;
}
