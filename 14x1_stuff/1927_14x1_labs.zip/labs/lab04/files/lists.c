#include <stdlib.h>
#include <stdio.h>
#include "lists.h"


void printList(link list){
    link curr;
    for(curr = list; curr != NULL; curr= curr->next){
        printf("%d ",curr->item);
    }
    printf("\n");
}

link newList(){
    return NULL;
}

link newNode(Item item){
    link n = (link) malloc(sizeof(*n));
    n->item = item;
    n->next = NULL;
    return n;
}

//O(n)
link insertEnd(link list, link n){
    link curr;
    if(list == NULL){
        list = n;
    } else {
        for(curr = list; curr->next != NULL; curr = curr->next){
    
        }
        curr->next = n;
    }
    return list;
}

//O(1)
link insertFront(link list, link n){
   n->next = list;
   return n;
}

void freeList(link list){
  link curr = list;
  link next;   
  while(curr!= NULL){
        next = curr->next;
        free(curr);
        curr = next;
  }

}
